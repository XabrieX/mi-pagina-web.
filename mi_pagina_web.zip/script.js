function saludar() {
  alert("¡Hola! Gracias por visitar mi web.");
}
